#!/bin/bash
# Test connection To DC
host -t SRV _ldap._tcp.lab.local

sudo realm join --user=Admnistrator lab.local
