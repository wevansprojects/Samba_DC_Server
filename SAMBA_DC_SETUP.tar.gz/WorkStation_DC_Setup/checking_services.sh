#!/bin/bash
clear
systemctl list-unit-files --state=active --state=enabled --state=disabled --state=failed
