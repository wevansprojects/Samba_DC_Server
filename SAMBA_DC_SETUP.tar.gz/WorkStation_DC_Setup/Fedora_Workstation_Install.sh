#!/bin/bash
sudo dnf install realmd sssd adcli krb5-workstation

sudo nmcli connection modify "enp0s3" \
ipv4.addresses 192.168.68.145/24 \
ipv4.gateway 192.168.68.1 \
ipv4.dns 192.168.68.149 \
ipv4.method manual \
ipv4.ignore-auto-dns yes
