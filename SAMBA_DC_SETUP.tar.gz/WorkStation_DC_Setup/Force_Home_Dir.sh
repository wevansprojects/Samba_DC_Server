#!/bin/bash
sudo authselect select sssd with-mkhomedir --force
