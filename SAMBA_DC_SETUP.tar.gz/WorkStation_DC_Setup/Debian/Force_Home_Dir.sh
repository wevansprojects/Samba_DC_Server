#!/bin/bash
sudo pam-auth-update --force
rm /etc/nsswitch.conf
sudo tee /etc/nsswitch.conf <<EOF
# /etc/nsswitch.conf
passwd:         files sss systemd
group:          files sss systemd
shadow:         files sss
gshadow:        files

hosts:          files dns
networks:       files

protocols:      db files
services:       db files
ethers:         db files
rpc:            db files

netgroup:       nis
EOF
