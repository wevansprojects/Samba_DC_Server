#!/bin/bash
sudo apt update
sudo apt install realmd sssd sssd-tools libnss-sss libpam-sss krb5-user samba-common-bin

sudo nmcli connection modify "Wired Connection 1" \
ipv4.addresses 192.168.68.145/24 \
ipv4.gateway 192.168.68.1 \
ipv4.dns 192.168.68.149 \
ipv4.method manual \
ipv4.ignore-auto-dns yes
