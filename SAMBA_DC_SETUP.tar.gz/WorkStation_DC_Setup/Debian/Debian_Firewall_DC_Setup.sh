#!/bin/bash
# Debian Workstation DC Firewall Setup
#
#domain	53	TCP/UDP
#kerberos	88	TCP/UDP
#epmap	135	TCP
#ldap	389	TCP/UDP
#microsoft-ds	445	TCP
#kpasswd	464	TCP/UDP

sudo ufw default deny incoming
sudo ufw allow ssh
sudo ufw allow kerberos
sudo ufw allow epmap
sudo ufw allow ldap
sudo ufw allow microsoft-ds
sudo ufw allow kpasswd
