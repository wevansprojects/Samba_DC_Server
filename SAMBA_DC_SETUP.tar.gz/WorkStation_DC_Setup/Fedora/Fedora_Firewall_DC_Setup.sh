# Allow standard Samba client communication
sudo firewall-cmd --permanent --add-service=samba-client

# Allow DNS responses (crucial for finding the DC)
sudo firewall-cmd --permanent --add-service=dns

# Allow Kerberos authentication traffic
sudo firewall-cmd --permanent --add-service=kerberos

# Reload to apply changes
sudo firewall-cmd --reload
