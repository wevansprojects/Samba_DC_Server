#!/bin/bash
# Forcing the sssd service to reconnect to the Domain
sudo systemctl stop sssd
sudo rm -rf /var/lib/sss/mc/*
sudo rm -rf /var/lib/sss/db/*
sudo systemctl start sssd
sudo sss_cache -E
sudo systemctl restart sssd

# Checking sssd service and log
# sssd service
sudo systemctl status sssd

# Log
#sudo su
#sudo cat /var/log/sssd/sssd.log
