# Checking the Network IP Address
Get-NetIPConfiguration

# Local User Accounts 
Get-CimInstance -ClassName win32_Desktop | Select-Object Name

# Joining the Domain
Get-CimInstance ClassName Win32_ComputerSystem | Select-Object Name,UserName,Domain
Add-Computer -DomainName "tektonik.com" -Credential (Get-Credential) -Restart
Get-CimInstance ClassName Win32_ComputerSystem | Select-Object Name,UserName,Domain
