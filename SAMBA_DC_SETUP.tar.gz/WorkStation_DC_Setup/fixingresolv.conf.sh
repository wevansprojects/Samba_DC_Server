#!/bin/bash
sudo rm /etc/resolv.conf
cat <<EOF | sudo tee /etc/resolv.conf
search lab.local
nameserver 192.168.68.149
EOF
#sudo chattr +i /etc/resolv.conf
#sudo chattr -i /etc/resolv.conf

# Test DNS
ping -c 3 google.com

# Test connection To DC
host -t SRV _ldap._tcp.lab.local
