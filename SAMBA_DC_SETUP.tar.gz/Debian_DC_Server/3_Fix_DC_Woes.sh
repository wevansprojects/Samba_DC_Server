#!/bin/bash
# 1. Disable systemd-resolved to prevent resolv.conf hijacking
sudo systemctl stop dhcpcd
sudo systemctl disable dhcpcd
sudo rm /etc/resolv.conf

# 2. Create the Static IP
cat << EOF | sudo tee /etc/network/interfaces #The primary network interface
auto enp0s3
iface enp0s3 inet static
    address 192.168.68.149
    netmask 255.255.255.0
    gateway 192.168.68.1
    dns-nameservers 127.0.0.1 8.8.8.8
    dns-search lab.local
EOF
# 3. Create a static resolv.conf
cat <<EOF | sudo tee /etc/resolv.conf
# Samba Server IP Address
nameserver 192.168.68.155

# fallback resolver
nameserver 8.8.8.8

# Main Domain For Samba
search dc1.tektonik.com
EOF

# 3. Make it immutable so it CANNOT be changed by any process
#sudo chattr +i /etc/resolv.conf

