#!/bin/bash
# set up Time Synchronization
Set permissions
# allow group _chrony to read the directory ntp_signd
sudo chown root:_chrony /var/lib/samba/ntp_signd/
 
# change the permission of the directory ntp_signd
sudo chmod 750 /var/lib/samba/ntp_signd/
Update Chrony
add the following to /etc/chrony/chrony.conf

# bind the chrony service to IP address of the Samba AD
bindcmdaddress 192.168.0.254
 
# allow clients on the network to connect to the Chrony NTP server
allow 192.168.0.0/24
 
# specify the ntpsigndsocket directory for the Samba AD
ntpsigndsocket /var/lib/samba/ntp_signd
# Then restart Chrony and get it’s status
# restart chronyd service
sudo systemctl restart chronyd
 
# verify chronyd service status
sudo systemctl status chronyd
Verifying Samba Active Directory
Run the following to verify
# verify domain example.lan
host -t A tektonik.com
 
# verify domain dc1.example.lan
host -t A dc1.tektonik.com
# Then verify the Kerberos and ldap services
# verify SRV record for _kerberos
host -t SRV _kerberos._udp.tektonik.com
 
# verify SRV record for _ldap
host -t SRV _ldap._tcp.tektonik.com
# Then verify the Samba resources
# verify SRV record for _kerberos
host -t SRV _kerberos._udp.tektonik.com
 
# verify SRV record for _ldap
host -t SRV _ldap._tcp.tektonik.com
# Lastly KINIT
# authenticate to Kerberos using administrator (MUST BE IN CAPS)
kinit administrator@TEKTONIK.COM
 
# verify list cached Kerberos tickets
klist
# Create your first user (Optional)
# The reason why this is optional, is you have more options when adding a user through the Remote Server Administration Tools (RSAT) on Windows.

# create a new user in Samba
sudo samba-tool user create admin
 
# checking users on Samba
sudo samba-tool user list

