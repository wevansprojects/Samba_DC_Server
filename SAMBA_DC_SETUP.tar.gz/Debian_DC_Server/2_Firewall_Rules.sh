#!/bin/bash
# 1. Active Directory Core Services
sudo ufw allow 53/tcp    # DNS
sudo ufw allow 53/udp    # DNS
sudo ufw allow 88/tcp    # Kerberos
sudo ufw allow 88/udp    # Kerberos
sudo ufw allow 135/tcp   # RPC Endpoint Mapper
sudo ufw allow 137/udp   # NetBIOS Name Service
sudo ufw allow 138/udp   # NetBIOS Datagram Service
sudo ufw allow 139/tcp   # NetBIOS Session Service
sudo ufw allow 389/tcp   # LDAP
sudo ufw allow 389/udp   # LDAP
sudo ufw allow 445/tcp   # SMB/CIFS
sudo ufw allow 464/tcp   # Kerberos Password Change
sudo ufw allow 464/udp   # Kerberos Password Change
sudo ufw allow 636/tcp   # LDAPS (SSL)
sudo ufw allow 3268/tcp  # Global Catalog
sudo ufw allow 3269/tcp  # Global Catalog SSL

# 2. RPC Dynamic Ports (Samba uses these for AD communication)
sudo ufw allow 49152:65535/tcp

# 3. Enable Firewall
sudo ufw enable

