#!/bin/bash
# Install required packages
sudo apt install -y samba ldb-tools smbclient krb5-config krb5-user winbind libpam-winbind libnss-winbind python3-samba attr acl
