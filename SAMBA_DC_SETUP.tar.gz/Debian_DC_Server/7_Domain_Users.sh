#!/bin/bash

#Run this to add the guid
#sudo ldbedit -H /var/lib/samba/private/sam.ldb '(cn=Domain Users)'
# Add this to the bottom of the file
#gidNumber: 513

#Run this to add the guid
#sudo ldbedit -H /var/lib/samba/private/sam.ldb '(cn=Domain Admins)'
#gidNumber: 512

