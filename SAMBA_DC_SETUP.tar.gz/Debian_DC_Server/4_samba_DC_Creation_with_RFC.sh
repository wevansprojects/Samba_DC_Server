#!/bin/bash
# Stop and mask services that we don't need in DC mode
sudo systemctl stop samba-ad-dc smbd nmbd winbind
sudo systemctl disable smbd nmbd winbind
sudo systemctl mask smbd nmbd winbind

# Back up original config
sudo mv /etc/samba/smb.conf /etc/samba/smb.conf.bak

# Provision the domain without RFC2307 enabled
sudo samba-tool domain provision \
 --use-rfc2307 \
 --realm=LAB.LOCAL \
 --domain=LAB \
 --server-role=dc \
 --dns-backend=SAMBA_INTERNAL \
 --adminpass='LinuxFever$4'

