#!/bin/bash
sudo samba-tool user create labadmin --uid-number=10001 --gid-number=10001 --login-shell=/bin/bash
sudo samba-tool group addmembers "Domain Admins" labadmin

sudo samba-tool user create labuser --uid-number=10002 --gid-number=10002 --login-shell=/bin/bash

# Editing Users If Needed
# sudo samba-tool user edit labuser

# Editing Domain Users If Needed
# sudo ldbedit -H /var/lib/samba/private/sam.ldb '(cn=Domain Users)'
