#!/bin/bash
# Stop and mask services that we don't need in DC mode
sudo systemctl stop samba-ad-dc smbd nmbd winbind
sudo systemctl disable smbd nmbd winbind
sudo systemctl mask smbd nmbd winbind

# Back up original config
sudo mv /etc/samba/smb.conf /etc/samba/smb.conf.bak

# Provision the domain without RFC2307 enabled
sudo samba-tool domain provision \
 --realm=LAB.LOCAL \
 --domain=LAB \
 --server-role=dc \
 --dns-backend=SAMBA_INTERNAL \
 --adminpass='LinuxFever$4'

# Link the Samba-generated krb5.conf to the system location
sudo cp /var/lib/samba/private/krb5.conf /etc/krb5.conf

# Unmask and start the AD DC service
sudo systemctl unmask samba-ad-dc
sudo systemctl enable --now samba-ad-dc
