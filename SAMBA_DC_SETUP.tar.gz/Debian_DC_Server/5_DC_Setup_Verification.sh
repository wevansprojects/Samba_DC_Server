#!/bin/bash
# if it breaks try this
#sudo systemctl stop smbd nmbd winbind;sudo systemctl disable smbd nmbd winbind
#sudo systemctl unmask samba-ad-dc;sudo systemctl restart samba-ad-dc
#ln -s /var/lib/samba/private/krb5.conf /etc/krb5.conf
# 1. Check DNS resolution of the DC
host -t A dc1.lab.local

# 2. Check SRV records (Crucial for Fedora clients to find the DC)
host -t SRV _ldap._tcp.lab.local

# 3. Test Kerberos authentication
kinit Administrator@LAB.LOCAL
# (Enter your password. If no error occurs, it worked)
klist

